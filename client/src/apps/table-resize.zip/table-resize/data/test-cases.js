export default [
  {
    generatedOn: "2/5/2020 08:11:10 PM",
    suiteName: "TestSuite2",
    projectName: "IOT",
    executionType: "Qualitia",
    iterationNo: 55,
    totalSize: 1.2,
    reportSize: 200,
    images: 0,
    logs: 0,
    testCases: 124,
    testCaseStat: {
      passed: 70,
      withDefects: 6,
      failed: 30,
      notExecuted: 18
    }
  },
  {
    generatedOn: "2/5/2020 08:11:10 PM",
    suiteName: "TestSuite2",
    projectName: "IOT",
    executionType: "Qualitia",
    iterationNo: 55,
    totalSize: 1.2,
    reportSize: 200,
    images: 0,
    logs: 0,
    testCases: 124,
    testCaseStat: {
      passed: 70,
      withDefects: 6,
      failed: 30,
      notExecuted: 18
    }
  },
  {
    generatedOn: "2/5/2020 08:11:10 PM",
    suiteName: "TestSuite2",
    projectName: "IOT",
    executionType: "Qualitia",
    iterationNo: 55,
    totalSize: 1.2,
    reportSize: 200,
    images: 0,
    logs: 0,
    testCases: 124,
    testCaseStat: {
      passed: 70,
      withDefects: 6,
      failed: 30,
      notExecuted: 18
    }
  },
  {
    generatedOn: "2/5/2020 08:11:10 PM",
    suiteName: "TestSuite2",
    projectName: "IOT",
    executionType: "Qualitia",
    iterationNo: 55,
    totalSize: 1.2,
    reportSize: 200,
    images: 0,
    logs: 0,
    testCases: 124,
    testCaseStat: {
      passed: 70,
      withDefects: 6,
      failed: 30,
      notExecuted: 18
    }
  },
  {
    generatedOn: "2/5/2020 08:11:10 PM",
    suiteName: "TestSuite2",
    projectName: "IOT",
    executionType: "Qualitia",
    iterationNo: 55,
    totalSize: 1.2,
    reportSize: 200,
    images: 0,
    logs: 0,
    testCases: 124,
    testCaseStat: {
      passed: 70,
      withDefects: 6,
      failed: 30,
      notExecuted: 18
    }
  },
  {
    generatedOn: "2/5/2020 08:11:10 PM",
    suiteName: "TestSuite2",
    projectName: "IOT",
    executionType: "Qualitia",
    iterationNo: 55,
    totalSize: 1.2,
    reportSize: 200,
    images: 0,
    logs: 0,
    testCases: 124,
    testCaseStat: {
      passed: 70,
      withDefects: 6,
      failed: 30,
      notExecuted: 18
    }
  },
  {
    generatedOn: "2/5/2020 08:11:10 PM",
    suiteName: "TestSuite2",
    projectName: "IOT",
    executionType: "Qualitia",
    iterationNo: 55,
    totalSize: 1.2,
    reportSize: 200,
    images: 0,
    logs: 0,
    testCases: 124,
    testCaseStat: {
      passed: 30,
      withDefects: 6,
      failed: 30,
      notExecuted: 18
    }
  }
];

export default [
  "Generated On",
  "Suite Name",
  "Project Name",
  "Execution Type",
  "Iteration No.",
  "Total Size",
  "Report Size",
  "Images",
  "Logs",
  "Test Cases",
  "Test Case Status"
]
export const ADD_TEST_CASE = "ADD_TEST_CASE";

export const REMOVE_TEST_CASE = "REMOVE_TEST_CASE";
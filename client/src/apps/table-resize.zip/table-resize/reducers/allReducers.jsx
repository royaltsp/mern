import { combineReducers } from "redux";
import testCaseReducer from './testCaseReducer'

export const allReducers = combineReducers({
  testCaseReducer
})